# RoadLens Australia — Website Submission Folder

## Open the website
- Easiest: double-click `index.html`. All core pages, charts and filters work locally.
- Best experience: run a simple local server from this folder: `python -m http.server 8000`, then open `http://localhost:8000`. This also enables the service worker.

## 10 required pages
1. `index.html` — Home
2. `dashboard.html` — Dashboard
3. `trends.html` — National trends
4. `states.html` — State comparison
5. `road-users.html` — Road users
6. `demographics.html` — Demographics
7. `risk-factors.html` — Risk factors
8. `explorer.html` — Data explorer / CSV export
9. `about-data.html` — Dataset, integration and limitations
10. `about.html` — About us, architecture, accessibility, privacy and security


## Built-in responsive preview
Every page includes a floating **View** control with three live options:
- **Desktop** — 1280 px preview
- **Tablet** — 820 px preview
- **Mobile** — 390 px preview

Selecting a device opens the current page in a live embedded frame at that viewport width, so the responsive breakpoints, navigation, grids, charts and content can be demonstrated directly inside the website. Press **Esc** or **Close ×** to return to the normal view.

## Main technology
- HTML5 semantic structure
- CSS3 responsive layout and custom properties
- Vanilla JavaScript (no third-party framework required)
- Local structured dataset in `data/roadlens-data.js` and JSON copy in `data/roadlens-data.json`
- HTML Canvas charts with accessible table alternatives
- PWA manifest + service worker (when served via HTTP/HTTPS)

## Data source
Australian Government National Road Safety Data Hub, *Monthly road deaths*, June 2026 release. The source page was last updated 15 July 2026 and notes that recent figures are preliminary and subject to revision.

## Security and privacy design
- No analytics, trackers, cookies, logins or remote libraries
- Restrictive Content Security Policy in each HTML page
- No inline JavaScript
- External links use `rel="noopener noreferrer"`
- Feedback form is local-only and does not transmit data

## Before submission
Replace group-member placeholders in the written report, review the report in your own words, run your own validation/Turnitin checks, and complete SPARK peer evaluation as required by the assessment brief.
