
(() => {
  'use strict';
  const D = window.ROADLENS_DATA;
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const $=(s,c=document)=>c.querySelector(s), $$=(s,c=document)=>[...c.querySelectorAll(s)];
  const fmt=n=>new Intl.NumberFormat('en-AU',{maximumFractionDigits:1}).format(n);

  const storage={get(k){try{return localStorage.getItem(k)}catch{return null}},set(k,v){try{localStorage.setItem(k,v)}catch{}}};

  function initResponsivePreview(){
    const params=new URLSearchParams(location.search);
    if(params.get('preview')==='1' || window.self!==window.top) return;

    const launcher=document.createElement('aside');
    launcher.className='device-preview-launcher';
    launcher.setAttribute('aria-label','Responsive preview options');
    launcher.innerHTML=`
      <span class="device-preview-label">View</span>
      <button type="button" class="device-option" data-device="desktop" aria-label="Preview desktop view">▱ <span>Desktop</span></button>
      <button type="button" class="device-option" data-device="tablet" aria-label="Preview tablet view">▯ <span>Tablet</span></button>
      <button type="button" class="device-option" data-device="mobile" aria-label="Preview mobile view">▯ <span>Mobile</span></button>`;
    document.body.appendChild(launcher);

    const overlay=document.createElement('div');
    overlay.className='device-preview-overlay';
    overlay.hidden=true;
    overlay.innerHTML=`
      <div class="device-preview-dialog" role="dialog" aria-modal="true" aria-labelledby="devicePreviewTitle">
        <div class="device-preview-topbar">
          <div>
            <strong id="devicePreviewTitle">Responsive preview</strong>
            <span id="devicePreviewSize" class="device-preview-size"></span>
          </div>
          <div class="device-preview-switcher" role="group" aria-label="Choose preview size">
            <button type="button" data-device="desktop">Desktop</button>
            <button type="button" data-device="tablet">Tablet</button>
            <button type="button" data-device="mobile">Mobile</button>
          </div>
          <button type="button" class="device-preview-close" aria-label="Close responsive preview">Close ×</button>
        </div>
        <div class="device-stage">
          <div class="device-frame" data-current-device="desktop">
            <iframe title="Live responsive preview of the current RoadLens page"></iframe>
          </div>
        </div>
      </div>`;
    document.body.appendChild(overlay);

    const frame=$('iframe',overlay), shell=$('.device-frame',overlay), size=$('#devicePreviewSize',overlay);
    const close=$('.device-preview-close',overlay);
    const deviceConfig={desktop:{width:1280,label:'Desktop · 1280px'},tablet:{width:820,label:'Tablet · 820px'},mobile:{width:390,label:'Mobile · 390px'}};
    let previousFocus=null;

    function previewUrl(){
      const u=new URL(location.href);
      u.searchParams.set('preview','1');
      return u.href;
    }
    function setDevice(device){
      const cfg=deviceConfig[device]||deviceConfig.desktop;
      shell.dataset.currentDevice=device;
      shell.style.setProperty('--preview-width',`${cfg.width}px`);
      size.textContent=cfg.label;
      $$('[data-device]',overlay).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.device===device)));
      if(!frame.src) frame.src=previewUrl();
    }
    function openPreview(device){
      previousFocus=document.activeElement;
      overlay.hidden=false;
      document.body.classList.add('preview-open');
      setDevice(device);
      close.focus();
    }
    function closePreview(){
      overlay.hidden=true;
      document.body.classList.remove('preview-open');
      previousFocus?.focus?.();
    }

    $$('.device-option',launcher).forEach(btn=>btn.addEventListener('click',()=>openPreview(btn.dataset.device)));
    $$('[data-device]',overlay).forEach(btn=>btn.addEventListener('click',()=>setDevice(btn.dataset.device)));
    close.addEventListener('click',closePreview);
    overlay.addEventListener('click',e=>{if(e.target===overlay)closePreview()});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!overlay.hidden)closePreview()});
  }

  function initCommon(){
    const stored=storage.get('roadlens-theme');
    if(stored) document.documentElement.dataset.theme=stored;
    $$('.theme-btn').forEach(btn=>btn.addEventListener('click',()=>{
      const next=document.documentElement.dataset.theme==='dark'?'light':'dark';
      document.documentElement.dataset.theme=next;storage.set('roadlens-theme',next);
      btn.setAttribute('aria-label',`Switch to ${next==='dark'?'light':'dark'} theme`);
      renderPageCharts();
    }));
    const menu=$('.menu-btn'), nav=$('.site-nav');
    if(menu&&nav) menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));});
    const page=document.body.dataset.page;
    $$(`.site-nav a[data-page]`).forEach(a=>{if(a.dataset.page===page)a.setAttribute('aria-current','page')});
    const year=$('#copyright-year');if(year)year.textContent=new Date().getFullYear();
    if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
  }

  function theme(){ const s=getComputedStyle(document.documentElement); return {ink:s.getPropertyValue('--ink').trim(),muted:s.getPropertyValue('--muted').trim(),line:s.getPropertyValue('--line').trim(),accent:s.getPropertyValue('--accent').trim(),teal:s.getPropertyValue('--teal').trim(),surface:s.getPropertyValue('--surface').trim()}; }
  function prepCanvas(canvas){const rect=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);return {ctx,w:rect.width,h:rect.height};}
  function drawBar(canvas, labels, values, opts={}){ if(!canvas)return; const {ctx,w,h}=prepCanvas(canvas),c=theme();ctx.clearRect(0,0,w,h);const pad={l:48,r:18,t:24,b:58};const max=Math.max(...values.filter(v=>v!=null))*1.12||1;const plotW=w-pad.l-pad.r, plotH=h-pad.t-pad.b;ctx.font='12px system-ui';ctx.fillStyle=c.muted;ctx.strokeStyle=c.line;ctx.lineWidth=1;for(let i=0;i<=4;i++){const y=pad.t+plotH*i/4;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();ctx.fillText(fmt(max*(1-i/4)),5,y+4)}const slot=plotW/labels.length,bar=Math.min(52,slot*.62);labels.forEach((lab,i)=>{const v=values[i]??0,x=pad.l+slot*i+(slot-bar)/2,bh=plotH*v/max,y=pad.t+plotH-bh;const grad=ctx.createLinearGradient(0,y,0,pad.t+plotH);grad.addColorStop(0,c.accent);grad.addColorStop(1,c.teal);ctx.fillStyle=grad;roundRect(ctx,x,y,bar,bh,8,true);ctx.fillStyle=c.muted;ctx.textAlign='center';ctx.fillText(lab,x+bar/2,h-30);ctx.fillStyle=c.ink;ctx.font='700 12px system-ui';ctx.fillText(fmt(v),x+bar/2,Math.max(16,y-7));ctx.font='12px system-ui'});ctx.textAlign='left';canvas.setAttribute('aria-label',opts.aria||'Bar chart');}
  function drawLine(canvas, series, labels=months, opts={}){ if(!canvas)return;const {ctx,w,h}=prepCanvas(canvas),c=theme();ctx.clearRect(0,0,w,h);const pad={l:46,r:18,t:26,b:48};const vals=series.flatMap(s=>s.values.filter(v=>v!=null));const min=Math.max(0,Math.min(...vals)-10),max=Math.max(...vals)+10,plotW=w-pad.l-pad.r,plotH=h-pad.t-pad.b;ctx.font='12px system-ui';ctx.strokeStyle=c.line;ctx.fillStyle=c.muted;for(let i=0;i<=4;i++){let y=pad.t+plotH*i/4;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();ctx.fillText(Math.round(max-(max-min)*i/4),6,y+4)}labels.forEach((lab,i)=>{const x=pad.l+plotW*i/(labels.length-1);ctx.textAlign='center';ctx.fillText(lab,x,h-18)});const cols=[c.accent,c.teal,c.ink,'#8c6bd6','#cf5c86','#6a8d3b'];series.forEach((s,si)=>{ctx.strokeStyle=cols[si%cols.length];ctx.fillStyle=cols[si%cols.length];ctx.lineWidth=2.5;ctx.beginPath();let started=false;s.values.forEach((v,i)=>{if(v==null)return;const x=pad.l+plotW*i/(labels.length-1),y=pad.t+plotH*(max-v)/(max-min);started?ctx.lineTo(x,y):ctx.moveTo(x,y);started=true});ctx.stroke();s.values.forEach((v,i)=>{if(v==null)return;const x=pad.l+plotW*i/(labels.length-1),y=pad.t+plotH*(max-v)/(max-min);ctx.beginPath();ctx.arc(x,y,3.5,0,Math.PI*2);ctx.fill()});});ctx.textAlign='left';canvas.setAttribute('aria-label',opts.aria||'Line chart');}
  function roundRect(ctx,x,y,w,h,r,fill){if(h<0){y+=h;h=-h}r=Math.min(r,w/2,h/2);ctx.beginPath();ctx.roundRect?ctx.roundRect(x,y,w,h,r):(ctx.rect(x,y,w,h));fill&&ctx.fill();}
  function rowsToTable(el, obj, label='Category'){if(!el)return;const rows=Object.entries(obj);el.innerHTML=`<thead><tr><th scope="col">${label}</th><th scope="col">Value</th></tr></thead><tbody>${rows.map(([k,v])=>`<tr><th scope="row">${k}</th><td>${fmt(v)}</td></tr>`).join('')}</tbody>`;}
  function setKPIs(){ const k=D.keyFigures;const map={monthly:k.monthlyDeaths,past12:k.past12Months,rate:k.fatalityRate,vru:k.vulnerableRoadUsers};Object.entries(map).forEach(([id,v])=>{const e=$(`[data-kpi="${id}"]`);if(e)e.textContent=fmt(v)});}
  function renderDashboard(){setKPIs();drawBar($('#stateChart'),Object.keys(D.stateDeaths['2026']),Object.values(D.stateDeaths['2026']),{aria:'Road deaths by state and territory for the 12 months ending June 2026'});drawLine($('#monthlyChart'),[{name:'2025',values:D.monthly['2025']},{name:'2026',values:D.monthly['2026']}],months,{aria:'Monthly road deaths in 2025 and January to June 2026'});}
  function renderTrends(){const y=$('#trendYear')?.value||'2026';drawLine($('#trendChart'),[{name:y,values:D.monthly[y]}]);const total=D.monthly[y].filter(v=>v!=null).reduce((a,b)=>a+b,0);const t=$('#trendTotal');if(t)t.textContent=fmt(total);const tb=$('#trendTable');if(tb)tb.innerHTML='<thead><tr><th scope="col">Month</th><th scope="col">Deaths</th></tr></thead><tbody>'+months.map((m,i)=>`<tr><th scope="row">${m}</th><td>${D.monthly[y][i]??'—'}</td></tr>`).join('')+'</tbody>';}
  function renderStates(){const y=$('#stateYear')?.value||'2026',metric=$('#stateMetric')?.value||'deaths',obj=metric==='rate'?D.stateRates[y]:D.stateDeaths[y];drawBar($('#statesChart'),Object.keys(obj),Object.values(obj),{aria:`${metric==='rate'?'Fatality rate':'Road deaths'} by state and territory in ${y}`});const sorted=Object.entries(obj).sort((a,b)=>b[1]-a[1]);const tb=$('#statesTable');if(tb)tb.innerHTML=`<thead><tr><th scope="col">Rank</th><th scope="col">State/Territory</th><th scope="col">${metric==='rate'?'Deaths per 100,000':'Deaths'}</th></tr></thead><tbody>${sorted.map(([s,v],i)=>`<tr><td><span class="rank">${i+1}</span></td><th scope="row">${s}</th><td>${fmt(v)}</td></tr>`).join('')}</tbody>`;}
  function renderRoadUsers(){const y=$('#roadUserYear')?.value||'2026',obj=D.roadUsers[y];drawBar($('#roadUserChart'),Object.keys(obj),Object.values(obj));rowsToTable($('#roadUserTable'),obj,'Road user');}
  function renderDemographics(){const y=$('#demoYear')?.value||'2026',tab=$('.tab[aria-selected="true"]')?.dataset.demo||'age';const sets={age:[D.ageGroups[y],'Age group'],gender:[D.gender[y],'Gender'],remoteness:[D.remoteness[y],'Remoteness area']};const [obj,label]=sets[tab];drawBar($('#demoChart'),Object.keys(obj),Object.values(obj));rowsToTable($('#demoTable'),obj,label);const note=$('#demoNote');if(note)note.textContent=tab==='remoteness'?'Caution: the Unknown remoteness category increased substantially in the latest period, so comparisons should be interpreted carefully.':'Figures are aggregate counts for the 12 months ending June of the selected year.';}
  function renderRisk(){const y=$('#riskYear')?.value||'2026';drawBar($('#crashChart'),Object.keys(D.crashType[y]),Object.values(D.crashType[y]));drawBar($('#speedChart'),Object.keys(D.speedLimit[y]),Object.values(D.speedLimit[y]));rowsToTable($('#speedTable'),D.speedLimit[y],'Speed limit (km/h)');}
  function getExplorerRows(){const cat=$('#explorerCategory')?.value||'stateDeaths',y=$('#explorerYear')?.value||'2026';const dict={stateDeaths:['State/Territory',D.stateDeaths],stateRates:['State/Territory',D.stateRates],roadUsers:['Road user',D.roadUsers],ageGroups:['Age group',D.ageGroups],gender:['Gender',D.gender],remoteness:['Remoteness',D.remoteness],crashType:['Crash type',D.crashType],speedLimit:['Speed limit',D.speedLimit]};const [label,all]=dict[cat];return {label,y,rows:Object.entries(all[y]).map(([category,value])=>({category,value}))};}
  function renderExplorer(){const {label,y,rows}=getExplorerRows();const q=($('#explorerSearch')?.value||'').toLowerCase();const filtered=rows.filter(r=>r.category.toLowerCase().includes(q)).sort((a,b)=>b.value-a.value);const tb=$('#explorerTable');if(tb)tb.innerHTML=`<thead><tr><th scope="col">${label}</th><th scope="col">Value</th><th scope="col">Year</th></tr></thead><tbody>${filtered.map(r=>`<tr><th scope="row">${r.category}</th><td>${fmt(r.value)}</td><td>${y}</td></tr>`).join('')}</tbody>`;const c=$('#explorerCount');if(c)c.textContent=`${filtered.length} rows`;
  }
  function exportExplorer(){const {label,y,rows}=getExplorerRows();const lines=[[label,'Value','Year'],...rows.map(r=>[r.category,r.value,y])].map(r=>r.map(x=>`"${String(x).replaceAll('"','""')}"`).join(',')).join('\n');const blob=new Blob([lines],{type:'text/csv'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`roadlens-${y}.csv`;a.click();URL.revokeObjectURL(a.href);}
  function initPage(){const p=document.body.dataset.page; if(p==='home')renderDashboard(); if(p==='dashboard')renderDashboard(); if(p==='trends'){renderTrends();$('#trendYear')?.addEventListener('change',renderTrends)} if(p==='states'){renderStates();$('#stateYear')?.addEventListener('change',renderStates);$('#stateMetric')?.addEventListener('change',renderStates)} if(p==='road-users'){renderRoadUsers();$('#roadUserYear')?.addEventListener('change',renderRoadUsers)} if(p==='demographics'){$$('.tab').forEach(t=>t.addEventListener('click',()=>{$$('.tab').forEach(x=>x.setAttribute('aria-selected','false'));t.setAttribute('aria-selected','true');renderDemographics()}));$('#demoYear')?.addEventListener('change',renderDemographics);renderDemographics()} if(p==='risk-factors'){renderRisk();$('#riskYear')?.addEventListener('change',renderRisk)} if(p==='explorer'){$$('#explorerCategory,#explorerYear').forEach(e=>e.addEventListener('change',renderExplorer));$('#explorerSearch')?.addEventListener('input',renderExplorer);$('#exportCsv')?.addEventListener('click',exportExplorer);renderExplorer()} if(p==='about'){$('#feedbackForm')?.addEventListener('submit',e=>{e.preventDefault();const name=$('#name').value.trim();$('#formMsg').textContent=`Thanks${name?`, ${name}`:''}. This demo keeps the feedback only in your browser and does not transmit it.`;e.target.reset()})}}
  function renderPageCharts(){requestAnimationFrame(()=>{const p=document.body.dataset.page;if(p==='home'||p==='dashboard')renderDashboard();else if(p==='trends')renderTrends();else if(p==='states')renderStates();else if(p==='road-users')renderRoadUsers();else if(p==='demographics')renderDemographics();else if(p==='risk-factors')renderRisk();});}
  let rt;window.addEventListener('resize',()=>{clearTimeout(rt);rt=setTimeout(renderPageCharts,120)});
  document.addEventListener('DOMContentLoaded',()=>{initCommon();initResponsivePreview();initPage()});
})();
