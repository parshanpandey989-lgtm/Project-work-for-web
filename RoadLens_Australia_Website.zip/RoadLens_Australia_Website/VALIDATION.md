# RoadLens Australia - validation notes

- 10 HTML pages are included and connected through the shared navigation.
- All local links were checked for missing targets.
- Every page contains a `<main>`, `<nav>` and `<h1>` landmark/heading.
- `assets/app.js` passes Node.js syntax checking.
- `data/roadlens-data.json` parses as valid JSON.
- The interface includes responsive layouts, keyboard focus styles, a skip link, labelled controls, reduced-motion handling and table alternatives to charts.
- A restrictive Content Security Policy is declared in each HTML page.

Before final Moodle submission, the group should also run the current W3C HTML/CSS validators and an accessibility checker in the browser and keep screenshots of the results if required by the lecturer.
